<?php
   $con=mysqli_connect("myrds-hhj.ctx1tbxsfdnp.ap-northeast-3.rds.amazonaws.com:3306", "day6", "epdltlrtm", "rookies9") or die("MySQL 접속 실패 !!");

   $sql ="SELECT name FROM userTbl WHERE userID={$_POST['fid']} and passWD={$_GET['fpwd']}";
 
   $ret = mysqli_query($con, $sql);   
   if($ret) {
      echo mysqli_num_rows($ret), "건이 조회됨..<br><br>";
      $count = mysqli_num_rows($ret);
   }
   else {
      echo "userTBL 데이터 조회 실패!!!"."<br>";
      echo "실패 원인 :".mysqli_error($con);
      exit();
   } 
      // session_start();
      // $host = 'localhost';
      // $user = '';
      // $pw = '';
      // $db_name = '';
      // $mysqli = new mysqli($host, $user, $pw, $db_name); //db 연결
      
      // //login.php에서 입력받은 id, password
      // $username = $_POST['id'];
      // $userpass = $_POST['pw'];
      
      // $q = "SELECT * FROM member WHERE id = '$username' AND pass = '$userpass'";
      // $result = $mysqli->query($q);
      // $row = $result->fetch_array(MYSQLI_ASSOC);
      
      // //결과가 존재하면 세션 생성
      // if ($row != null) {
      //    $_SESSION['username'] = $row['id'];
      //    $_SESSION['name'] = $row['name'];
      //    echo "<script>location.replace('index.php');</script>";
      //    exit;
      // }
      
      // //결과가 존재하지 않으면 로그인 실패
      // if($row == null){
      //    echo "<script>alert('Invalid username or password')</script>";
      //    echo "<script>location.replace('login.php');</script>";
      //    exit;
      // }
      ?>