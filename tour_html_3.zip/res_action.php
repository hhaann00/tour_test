<?php 

	echo "<script>
      window.alert('예약 완료');
      history.go(-1);
      </script>"
	// echo "
 //  <script>
 //    location.href='index.html'
 //  </script>";

 ?>
