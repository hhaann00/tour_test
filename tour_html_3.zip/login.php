<?php
   try {
      session_start();

      $userID = $_POST["fid"];
      $passWD = $_POST["fpwd"];

      $con=mysqli_connect("hhj-db.ctx1tbxsfdnp.ap-northeast-3.rds.amazonaws.com:3306", "day6", "epdltlrtm", "rookies9") or die("MySQL 접속 실패 !!");

      $sql ="SELECT * FROM userTbl WHERE userID='".$userID."' and passWD='".$passWD."';";
    
      $ret = mysqli_query($con, $sql); 

      if($ret) {
         $user = mysqli_fetch_array($ret);
         if($user['userID'] == $userID && $user['passWD'] == $passWD){
            $_SESSION['username'] = $user['name'];
            echo "<script>alert('{$user['name']}'+'님 환영합니다.');
            location.replace('index.php');</script>";
         } else {
            echo "<script>alert('유효하지 않은 아이디 혹은 패스워드입니다.');
            location.replace('login.html');</script>";
         }
      }
      else {
         echo "<script>alert('유효하지 않은 아이디 혹은 패스워드입니다.');
         location.replace('login.html');</script>";
      } 

      mysqli_close($con);


   } catch(Exception $e){
      echo 'Error : ' .$e->getMessage();
   }
?> 