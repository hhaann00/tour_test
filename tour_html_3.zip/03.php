<?php
   $con=mysqli_connect("hhj-db.ctx1tbxsfdnp.ap-northeast-3.rds.amazonaws.com:3306", "day6", "epdltlrtm", "rookies9") or die("MySQL 접속 실패 !!");

   try {
	   $sql ="
		   CREATE TABLE userTbl 
			( userID  	CHAR(8) NOT NULL PRIMARY KEY,
			  name    	VARCHAR(10) NOT NULL,
			  passWD    	VARCHAR(18) NOT NULL,
			  birthYear   INT NOT NULL,
			  addr	  	CHAR(2) NOT NULL,
			  mobile1	CHAR(3),
			  mobile2	CHAR(11)
			)
	   ";
	 
	   $ret = mysqli_query($con, $sql);
	 
	   if($ret) {
		   echo "userTbl이 성공적으로 생성됨..";
	   }
	   else {
		   echo "userTbl 생성 실패!!!"."<br>";
		   echo "실패 원인 :".mysqli_error($con);
	   }
	 
	   mysqli_close($con);
	}
	catch(Exception $e){
		echo 'Error : ' .$e->getMessage();
	}
?>
