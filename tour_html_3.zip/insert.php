<?php
   $con=mysqli_connect("hhj-db.ctx1tbxsfdnp.ap-northeast-3.rds.amazonaws.com:3306", "day6", "epdltlrtm", "rookies9") or die("MySQL 접속 실패 !!");

   $userID = $_POST["fid"];
   $name = $_POST["fname"];
   $birthYear = $_POST["fbirth"];
   $addr = $_POST["faddr"];
   $mobile1 = $_POST["fmobile1"];
   $mobile2 = $_POST["fmobile2"];
   $passWD = $_POST["fpwd"];
   
   $sql =" INSERT INTO userTbl VALUES('".$userID."','".$name."','".$passWD."','".$birthYear;
   $sql = $sql."','".$addr."','".$mobile1."','".$mobile2."')";
   
   $ret = mysqli_query($con, $sql);
 
   
   mysqli_close($con);

   echo "<script>
      window.alert('회원가입 완료');
      history.go(-1);
      </script>"

?>