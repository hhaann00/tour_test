<?php
   $con=mysqli_connect("mydb.ctx1tbxsfdnp.ap-northeast-3.rds.amazonaws.com:3306", "day6", "epdltlrtm", "rookies9") or die("MySQL 접속 실패 !!");

   $sql ="
		INSERT INTO userTbl VALUES
		('IU', '이지은', 'dkdldb', '20100505', '서울', '+82', '01025537930')
   ";
 
   $ret = mysqli_query($con, $sql);
 
   if($ret) {
	   echo "userTbl이 데이터가 성공적으로 입력됨.";
   }
   else {
	   echo "userTbl 데이터 입력 실패!!!"."<br>";
	   echo "실패 원인 :".mysqli_error($con);
   }
 
   mysqli_close($con);
?>
