<?php 
	session_start();

	echo "<script>
      window.alert('예약 완료');
      history.go(-1);
      </script>";


	$userID = $_SESSION['userID'];
	echo $userID;

	$con=mysqli_connect("mydb.ctx1tbxsfdnp.ap-northeast-3.rds.amazonaws.com:3306", "day6", "epdltlrtm", "rookies9") or die("MySQL 접속 실패 !!");

	$country = $_POST["country"];
	$date = $_POST["daterange"];
	$count = $_POST["count"];

	$message = '[Tour]<br>'.$date.', '.$country.', '.$count.'명으로 예약 확인되었습니다.<br> 감사합니다.';


	$sql ="SELECT * FROM userTbl WHERE userID='".$userID."' limit 1;";

	$ret = mysqli_query($con, $sql); 

	if($ret) {
		$user = mysqli_fetch_array($ret);
		$phone = $user['mobile1'].$user['mobile2'];
		echo $phone;
	 
	}
	else {
		echo "<script>alert('유효하지 않은 아이디 혹은 패스워드입니다.');
	 	location.replace('login.html');</script>";
	}


	exec("php ./res_action.php");


   

 ?>
