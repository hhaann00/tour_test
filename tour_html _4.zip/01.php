<?php
	try{
	   $db_host="mydb.ctx1tbxsfdnp.ap-northeast-3.rds.amazonaws.com:3306";
	   $db_user="day6";
	   $db_password="epdltlrtm";
	   $db_name="rookies9";
	   $con=mysqli_connect($db_host, $db_user, $db_password, $db_name);
	   if ( mysqli_connect_error($con) ) {
		   echo "MySQL 접속 실패 !!", "<br>";
		   echo "오류 원인 : ", mysqli_connect_error();
		   exit();
	   }
	   echo "MySQL 접속 완전히 성공!!";
	   mysqli_close($con);
	}
	catch(Exception $e){
		echo 'Error : ' .$e->getMessage();
	}
?>
